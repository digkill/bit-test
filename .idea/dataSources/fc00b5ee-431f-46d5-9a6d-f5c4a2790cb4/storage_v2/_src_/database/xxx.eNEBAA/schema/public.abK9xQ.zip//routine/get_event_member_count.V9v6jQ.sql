create function get_event_member_count()
    returns TABLE(event_id bigint, student_count bigint)
    language plpgsql
as
$$
BEGIN
              RETURN QUERY
              WITH vsm AS (
                  SELECT
                    v.doc_event_id,
                    m2.member_type,
                    m2.member_id
                  FROM visibility_group v
                    LEFT JOIN visibility_group_member m2 ON v.id = m2.visibility_group_id
                  WHERE doc_event_id IN (SELECT id FROM doc_event e WHERE event_is_active(e))
              ), vgm AS (
                SELECT
                  vsm.doc_event_id,
                  m2.member_type,
                  m2.member_id
                FROM vsm
                  LEFT JOIN visibility_group_member m2 ON vsm.member_id = m2.visibility_group_id
                WHERE vsm.member_type = 16
                UNION
                SELECT *
                FROM vsm
                WHERE vsm.member_type != 16
              )
                  SELECT
                    doc_event_id,
                    count(student_id) quantity
                  FROM
                    (SELECT DISTINCT
                       doc_event_id,
                       CASE WHEN vgm.member_type = 1
                         THEN vgm.member_id
                       ELSE s.id END student_id
                     FROM vgm
                       LEFT JOIN lnk_teacher_grade l ON vgm.member_type = 2 AND vgm.member_id = l.teacher_id
                       LEFT JOIN grade g ON vgm.member_type = 8 AND vgm.member_id = g.school_id
                       LEFT JOIN student s ON (vgm.member_type = 2 AND l.grade_id = s.grade_id)/*by teacher*/ OR
                                              (vgm.member_type = 4 AND vgm.member_id = s.grade_id) /*by grade*/ OR
                                              (vgm.member_type = 8 AND g.id = s.grade_id) /*by school*/) s
                  GROUP BY doc_event_id;
            END;
$$;

alter function get_event_member_count() owner to postgres;

