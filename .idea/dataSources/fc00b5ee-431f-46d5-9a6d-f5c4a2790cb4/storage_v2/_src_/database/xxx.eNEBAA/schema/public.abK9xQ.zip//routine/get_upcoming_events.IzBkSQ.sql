create function get_upcoming_events(students_ids bigint[])
    returns TABLE(event_id bigint, predecessor bigint, student_id bigint, start_date timestamp without time zone, end_date timestamp without time zone, title character varying, description text, first_name character varying, last_name character varying, forms_signed integer, forms_to_sign integer, products_purchased integer, products_to_purchase integer, gender integer, status integer, status_upcoming smallint, required boolean, img_url character varying, type smallint, due_date timestamp without time zone, is_repeatable boolean, repeat_on_days integer)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  WITH members AS (
    -- select student info:
      SELECT
        s.id,
        s.grade_id,
        g.school_id,
        ltg.teacher_id
      FROM
        student s
        LEFT JOIN grade g ON s.grade_id = g.id
        LEFT JOIN lnk_teacher_grade ltg on g.id = ltg.grade_id
      WHERE
        s.id = ANY (students_ids)
  ), groups AS (
    -- select all groups
      SELECT vgm.*
      FROM visibility_group vg
        LEFT JOIN visibility_group_member vgm ON (vg.id = vgm.visibility_group_id)
        INNER JOIN members m ON (vgm.member_type = 1 AND vgm.member_id = m.id) OR
                                (vgm.member_type = 2 AND vgm.member_id = m.teacher_id) OR
                                (vgm.member_type = 4 AND vgm.member_id = m.grade_id) OR
                                (vgm.member_type = 8 AND vgm.member_id = m.school_id)
      WHERE vg.doc_event_id IS NULL
    -- union students and groups
  ), all_members AS (
      SELECT
        m.*,
        g.visibility_group_id group_id
      FROM members m
        LEFT JOIN groups g ON (g.member_type = 1 AND g.member_id = m.id) OR
                              (g.member_type = 2 AND g.member_id = m.teacher_id) OR
                              (g.member_type = 4 AND g.member_id = m.grade_id) OR
                              (g.member_type = 8 AND g.member_id = m.school_id)
  )
  SELECT
    DISTINCT ON (doc_event.start_date, doc_event.id, student.id)
    doc_event.id,
    doc_event.predecessor,
    student.id,
    doc_event.start_date,
    doc_event.end_date,
    doc_event.title,
    doc_event.description,
    student.first_name,
    student.last_name,
    less.forms_signed,
    les.forms_to_sign,
    less.products_purchased,
    les.products_to_purchase,
    student.gender,
    doc_event.status,
	less.status as status_upcoming,
    doc_event.is_parent_action_required,
    ph.url,
    doc_event.type,
    CASE WHEN doc_event.is_repeatable
      THEN nearest_due_date(doc_event.id)
    ELSE doc_event.due_date END due_date,
    doc_event.is_repeatable,
    p.repeat_on_days
  FROM
    (doc_event
      LEFT JOIN
      visibility_group vg ON doc_event.id = vg.doc_event_id OR doc_event.predecessor = vg.doc_event_id
      LEFT JOIN
      visibility_group_member vgm on vg.id = vgm.visibility_group_id)
    INNER JOIN all_members m ON (vgm.member_type = 1 AND vgm.member_id = m.id) OR
                                (vgm.member_type = 2 AND vgm.member_id = m.teacher_id) OR
                                (vgm.member_type = 4 AND vgm.member_id = m.grade_id) OR
                                (vgm.member_type = 8 AND vgm.member_id = m.school_id) OR
                                (vgm.member_type = 16 AND vgm.member_id = m.group_id)
    INNER JOIN ldg_event_status les ON doc_event.id = les.doc_event_id
    LEFT JOIN student ON (m.id = student.id)
    LEFT JOIN ldg_event_student_status less on doc_event.id = less.doc_event_id AND student.id = less.student_id
    LEFT JOIN event_photo ph ON doc_event.id = ph.event_id AND ph.is_main
    LEFT JOIN doc_event p ON doc_event.predecessor = p.id
  WHERE event_is_active(doc_event)
        AND (doc_event.predecessor IS NULL OR (less.status = 1 OR less.status = 32))
        AND (NOT coalesce(doc_event.is_repeatable, false) OR has_opened_children_events(doc_event.id, student.id))
  ORDER BY doc_event.start_date;
END;
$$;

alter function get_upcoming_events(bigint[]) owner to postgres;

