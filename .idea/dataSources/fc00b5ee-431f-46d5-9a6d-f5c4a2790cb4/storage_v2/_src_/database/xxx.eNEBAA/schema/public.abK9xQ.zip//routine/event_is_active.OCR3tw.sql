create function event_is_active(e doc_event) returns boolean
    language plpgsql
as
$$
BEGIN
  RETURN e.end_date > NOW() AND (e.status = 4 OR e.status = 8);
END;
$$;

alter function event_is_active(doc_event) owner to postgres;

