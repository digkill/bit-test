create function update_parent_status(event_id bigint, student bigint, status_planned integer, status_declined integer) returns void
    language plpgsql
as
$$
DECLARE   new_status     INTEGER;
  DECLARE predecessor_id INTEGER;
BEGIN
  SELECT predecessor
  INTO predecessor_id
  FROM doc_event e
  WHERE e.id = event_id;
  IF predecessor_id IS NULL
  THEN RETURN; END IF;
  SELECT CASE WHEN ls.quantity = ls.total
    THEN
      CASE WHEN (ls.status & ~(status_planned | status_declined)) > 0
        THEN 0
      WHEN ls.status & status_planned > 0
        THEN status_planned
      ELSE status_declined END
         ELSE 0 END
  INTO new_status
  FROM (SELECT
          count(e.id)      total,
          count(l.id)      quantity,
          bit_or(l.status) status
        FROM doc_event e
          LEFT JOIN ldg_event_student_status l on e.id = l.doc_event_id AND l.student_id = student
        WHERE e.predecessor = predecessor_id) ls;
  IF (new_status > 0)
  THEN
    INSERT INTO ldg_event_student_status
    (doc_event_id, student_id, status, forms_signed, products_purchased)
    VALUES (predecessor_id, student, new_status, 0, 0);
  END IF;

END;
$$;

alter function update_parent_status(bigint, bigint, integer, integer) owner to postgres;

