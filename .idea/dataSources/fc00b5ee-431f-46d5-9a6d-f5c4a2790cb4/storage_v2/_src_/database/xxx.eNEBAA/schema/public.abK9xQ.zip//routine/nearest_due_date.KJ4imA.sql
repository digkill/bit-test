create function nearest_due_date(event_id bigint) returns timestamp without time zone
    language plpgsql
as
$$
BEGIN
  RETURN (
    SELECT min(due_date)
    FROM doc_event e
      LEFT JOIN ldg_event_student_status l on e.id = l.doc_event_id
    WHERE predecessor = event_id AND due_date > NOW() AND (coalesce(l.status, 8) & 3 = 0)
  );
END;
$$;

alter function nearest_due_date(bigint) owner to postgres;

