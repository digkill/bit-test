create function has_opened_children_events(event bigint, student bigint) returns boolean
    language plpgsql
as
$$
BEGIN
  RETURN (SELECT EXISTS(
      SELECT 1
      FROM doc_event ce
        LEFT JOIN ldg_event_student_status l ON ce.id = l.doc_event_id AND l.student_id = student
      WHERE ce.predecessor = event AND (l.status IS NULL OR l.status != 1) AND ce.due_date > NOW()
  ));
END;
$$;

alter function has_opened_children_events(bigint, bigint) owner to postgres;

