create function update_status_counters(event_id bigint, guardian bigint, student bigint, purchased integer, signed integer, status_planned integer, status_declined integer, status_incomplete integer) returns void
    language plpgsql
as
$$
DECLARE new_status INTEGER;
BEGIN
  SELECT CASE WHEN products_to_purchase = coalesce(ss.products_purchased, 0) + purchased AND
                   forms_to_sign = coalesce(ss.forms_signed, 0) + signed
    THEN status_planned
         ELSE status_incomplete END
  INTO new_status
  FROM ldg_event_status s
    LEFT JOIN ldg_event_student_status ss
      ON s.doc_event_id = ss.doc_event_id AND ss.student_id = student
  WHERE s.doc_event_id = event_id;
  INSERT INTO ldg_event_student_status AS ss
  (doc_event_id, student_id, status, forms_signed, products_purchased)
  VALUES (event_id, student, new_status, signed, purchased)
  ON CONFLICT (doc_event_id, student_id)
    DO UPDATE SET
      status             = new_status,
      products_purchased = ss.products_purchased + purchased,
      forms_signed       = ss.forms_signed + signed;
  UPDATE ldg_event_status
  SET
    products_purchased = products_purchased + purchased,
    forms_signed       = forms_signed + signed
  WHERE doc_event_id = event_id;
  IF new_status = status_planned
  THEN
    INSERT INTO ldg_event_activity_general
    (doc_event_id, guardian_id, student_id, action_type, created_at)
    VALUES (event_id, guardian, student, 1, NOW());
    PERFORM update_parent_status(event_id, student, status_planned, status_declined);
  END IF;
END;
$$;

alter function update_status_counters(bigint, bigint, bigint, integer, integer, integer, integer, integer) owner to postgres;

